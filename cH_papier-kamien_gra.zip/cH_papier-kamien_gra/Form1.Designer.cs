﻿namespace cH_papier_kamien_gra
{
    partial class Form1
    {
        /// <summary>
        /// Wymagana zmienna projektanta.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Wyczyść wszystkie używane zasoby.
        /// </summary>
        /// <param name="disposing">prawda, jeżeli zarządzane zasoby powinny zostać zlikwidowane; Fałsz w przeciwnym wypadku.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kod generowany przez Projektanta formularzy systemu Windows

        /// <summary>
        /// Metoda wymagana do obsługi projektanta — nie należy modyfikować
        /// jej zawartości w edytorze kodu.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.papier = new System.Windows.Forms.PictureBox();
            this.kamien = new System.Windows.Forms.PictureBox();
            this.nozyce = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.starcie = new System.Windows.Forms.Label();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.starcie1 = new System.Windows.Forms.PictureBox();
            this.starcie2 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.wynOst = new System.Windows.Forms.Label();
            this.Wyniki = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.papier)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kamien)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nozyce)).BeginInit();
            this.tableLayoutPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.starcie1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.starcie2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.SuspendLayout();
            // 
            // papier
            // 
            this.papier.Cursor = System.Windows.Forms.Cursors.Hand;
            this.papier.Image = ((System.Drawing.Image)(resources.GetObject("papier.Image")));
            this.papier.Location = new System.Drawing.Point(276, 269);
            this.papier.Name = "papier";
            this.papier.Size = new System.Drawing.Size(60, 60);
            this.papier.TabIndex = 1;
            this.papier.TabStop = false;
            this.papier.Click += new System.EventHandler(this.papier_Click);
            // 
            // kamien
            // 
            this.kamien.Cursor = System.Windows.Forms.Cursors.Hand;
            this.kamien.Image = ((System.Drawing.Image)(resources.GetObject("kamien.Image")));
            this.kamien.Location = new System.Drawing.Point(342, 269);
            this.kamien.Name = "kamien";
            this.kamien.Size = new System.Drawing.Size(60, 60);
            this.kamien.TabIndex = 2;
            this.kamien.TabStop = false;
            this.kamien.Click += new System.EventHandler(this.kamien_Click);
            // 
            // nozyce
            // 
            this.nozyce.Cursor = System.Windows.Forms.Cursors.Hand;
            this.nozyce.Image = ((System.Drawing.Image)(resources.GetObject("nozyce.Image")));
            this.nozyce.Location = new System.Drawing.Point(408, 269);
            this.nozyce.Name = "nozyce";
            this.nozyce.Size = new System.Drawing.Size(60, 60);
            this.nozyce.TabIndex = 3;
            this.nozyce.TabStop = false;
            this.nozyce.Click += new System.EventHandler(this.nozyce_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.label1.Location = new System.Drawing.Point(272, 244);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(203, 22);
            this.label1.TabIndex = 4;
            this.label1.Text = "papier   kamien   nożyce";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // starcie
            // 
            this.starcie.AutoSize = true;
            this.starcie.Font = new System.Drawing.Font("Segoe Print", 14F, System.Drawing.FontStyle.Bold);
            this.starcie.Location = new System.Drawing.Point(331, 173);
            this.starcie.Name = "starcie";
            this.starcie.Size = new System.Drawing.Size(82, 33);
            this.starcie.TabIndex = 5;
            this.starcie.Text = "Starcie";
            this.starcie.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.BackColor = System.Drawing.Color.Gold;
            this.tableLayoutPanel2.ColumnCount = 3;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel2.Controls.Add(this.starcie1, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.starcie2, 2, 0);
            this.tableLayoutPanel2.Controls.Add(this.pictureBox4, 1, 0);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(273, 89);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(200, 68);
            this.tableLayoutPanel2.TabIndex = 7;
            // 
            // starcie1
            // 
            this.starcie1.Location = new System.Drawing.Point(3, 3);
            this.starcie1.Name = "starcie1";
            this.starcie1.Size = new System.Drawing.Size(60, 60);
            this.starcie1.TabIndex = 0;
            this.starcie1.TabStop = false;
            // 
            // starcie2
            // 
            this.starcie2.Location = new System.Drawing.Point(135, 3);
            this.starcie2.Name = "starcie2";
            this.starcie2.Size = new System.Drawing.Size(60, 60);
            this.starcie2.TabIndex = 2;
            this.starcie2.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(69, 3);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(60, 60);
            this.pictureBox4.TabIndex = 1;
            this.pictureBox4.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(285, 73);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 13);
            this.label2.TabIndex = 8;
            this.label2.Text = "Gracz";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(414, 73);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(52, 13);
            this.label3.TabIndex = 9;
            this.label3.Text = "Komputer";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe Print", 14F, System.Drawing.FontStyle.Bold);
            this.label4.Location = new System.Drawing.Point(87, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(610, 33);
            this.label4.TabIndex = 10;
            this.label4.Text = "Graj z profesjonalnym komputerem w Papier Kamień Nożyce";
            // 
            // wynOst
            // 
            this.wynOst.AutoSize = true;
            this.wynOst.Font = new System.Drawing.Font("Segoe Print", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.wynOst.Location = new System.Drawing.Point(269, 348);
            this.wynOst.Name = "wynOst";
            this.wynOst.Size = new System.Drawing.Size(92, 37);
            this.wynOst.TabIndex = 11;
            this.wynOst.Text = "WYNIK";
            // 
            // Wyniki
            // 
            this.Wyniki.BackColor = System.Drawing.Color.Gold;
            this.Wyniki.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Wyniki.Font = new System.Drawing.Font("Segoe Print", 15.75F, System.Drawing.FontStyle.Bold);
            this.Wyniki.Location = new System.Drawing.Point(596, 89);
            this.Wyniki.Name = "Wyniki";
            this.Wyniki.Size = new System.Drawing.Size(143, 89);
            this.Wyniki.TabIndex = 12;
            this.Wyniki.Text = "werdykt ostateczny\r\n";
            this.Wyniki.UseVisualStyleBackColor = false;
            this.Wyniki.Click += new System.EventHandler(this.Wyniki_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightGoldenrodYellow;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.Wyniki);
            this.Controls.Add(this.wynOst);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.tableLayoutPanel2);
            this.Controls.Add(this.starcie);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.nozyce);
            this.Controls.Add(this.kamien);
            this.Controls.Add(this.papier);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Name = "Form1";
            this.Text = "Papier Kamień Nożyce";
            ((System.ComponentModel.ISupportInitialize)(this.papier)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kamien)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nozyce)).EndInit();
            this.tableLayoutPanel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.starcie1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.starcie2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.PictureBox papier;
        private System.Windows.Forms.PictureBox kamien;
        private System.Windows.Forms.PictureBox nozyce;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label starcie;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.PictureBox starcie1;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox starcie2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label wynOst;
        private System.Windows.Forms.Button Wyniki;
    }
}

