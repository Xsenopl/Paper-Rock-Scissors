﻿using System;                           //aplikacje wykonał Bogusław Szura
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;                    // zamiera w sobie m.in. klasę Path

namespace cH_papier_kamien_gra
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void papier_Click(object sender, EventArgs e)
        {
            walka(1);   this.starcie1.Image = Image.FromFile(Path.GetFullPath($@"..\..\grafiki\papier.jpg"));
        }
        private void kamien_Click(object sender, EventArgs e)
        {
            walka(2);   this.starcie1.Image = Image.FromFile(Path.GetFullPath($@"..\..\grafiki\kamien.jpg"));
        }
        private void nozyce_Click(object sender, EventArgs e)
        {
            walka(3);   this.starcie1.Image = Image.FromFile(Path.GetFullPath($@"..\..\grafiki\nozyce..jpg"));
        }

        static class Werdykt
        {
           public static int[] wynik = new int[2] { 0, 0 };
           private static double[] werdykt = new double[2] { 0, 0 };
            public static int a = 0, b = 0;
            public static bool c;
           private static bool kontrola;


            public static void dodawanie(bool kto)
            {
                if (kontrola == kto || (wynik[0] == 0 && wynik[1] == 0))
                {
                    if (kto)
                    {
                        werdykt[0] = werdykt[0] + (a * 0.5);
                    }
                    else
                    {
                        werdykt[1] = werdykt[1] + (b * 0.5);
                    }
                }
                else
                {
                    a = 0;
                    b = 0;
                }
                kontrola = kto;
             }
            public static double wynik_ost(int i)
             {
                werdykt[i] += wynik[i];
                return werdykt[i];
             }
            public static void odNowa()
            {
                wynik[0] = 0; wynik[1] = 0;  werdykt[0] = 0; werdykt[1] = 0;    a = 0; b = 0; c = false; kontrola = false;
            }
            
        }
        private void walka(int x)
        {
            this.starcie1.Visible = true;
            this.starcie2.Visible = true;
            Random rnd = new Random();
            int komp = rnd.Next(1, 4);
            if(komp==1) this.starcie2.Image = Image.FromFile(Path.GetFullPath($@"..\..\grafiki\papier.jpg"));
            if(komp==2) this.starcie2.Image = Image.FromFile(Path.GetFullPath($@"..\..\grafiki\kamien.jpg"));
            if(komp==3) this.starcie2.Image = Image.FromFile(Path.GetFullPath($@"..\..\grafiki\nozyce..jpg"));

//          sprawdzam kto wygrał - ile razy z rzędu - czy to gracz czy komp   - bonus za wygraną z rzędu        - wypisuje stosunek zwycięstw do przegranych
            if (x==komp)                                                                                      { this.starcie.Text = $"Remis\n{Werdykt.wynik[0]}-{Werdykt.wynik[1]}";            }
            else if(x==1 && komp==2)    { Werdykt.a++; Werdykt.c = true;      Werdykt.dodawanie(Werdykt.c);     this.starcie.Text = $"Wygrałeś\n{++Werdykt.wynik[0]}-{Werdykt.wynik[1]}";       }
            else if(x==1 && komp==3)    { Werdykt.b++; Werdykt.c = false;     Werdykt.dodawanie(Werdykt.c);     this.starcie.Text = $"Przegrałeś\n{Werdykt.wynik[0]}-{++Werdykt.wynik[1]}";     }
            else if(x==2 && komp==1)    { Werdykt.b++; Werdykt.c = false;     Werdykt.dodawanie(Werdykt.c);     this.starcie.Text = $"Przegrałeś\n{Werdykt.wynik[0]}-{++Werdykt.wynik[1]}";     }
            else if(x==2 && komp==3)    { Werdykt.a++; Werdykt.c = true;      Werdykt.dodawanie(Werdykt.c);     this.starcie.Text = $"Wygrałeś\n{++Werdykt.wynik[0]}-{Werdykt.wynik[1]}";       }
            else if(x==3 && komp==1)    { Werdykt.a++; Werdykt.c = true;      Werdykt.dodawanie(Werdykt.c);     this.starcie.Text = $"Wygrałeś\n{++Werdykt.wynik[0]}-{Werdykt.wynik[1]}";       }
            else if(x==3 && komp==2)    { Werdykt.b++; Werdykt.c = false;     Werdykt.dodawanie(Werdykt.c);     this.starcie.Text = $"Przegrałeś\n{Werdykt.wynik[0]}-{++Werdykt.wynik[1]}";     }
        }

        private void Wyniki_Click(object sender, EventArgs e)
        {
            this.wynOst.Text = $"Gracz: {Werdykt.wynik_ost(0)}\n";
            this.wynOst.Text += $"Komputer {Werdykt.wynik_ost(1)}";
            Werdykt.odNowa();
            this.starcie1.Visible = false;
            this.starcie2.Visible = false;
        }
    }
}
